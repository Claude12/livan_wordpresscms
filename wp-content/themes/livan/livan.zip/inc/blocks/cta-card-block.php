<?php

/**
 * ACF: Flexible Content > Layouts > CTA Card Block
 *
 * @package WordPress
 */

$heading    = $section['cta_card_heading'];
$subheading = $section['cta_card_subheading'];
$cta_link   = $section['cta_card_link'];
?>

<section class="cta-card-block">
    <div class="container">
        <div class="cta-card-block__card" animate="fade-in">
            <?php if ($heading): ?>
                <h2 class="cta-card-block__heading"><?php echo esc_html($heading); ?></h2>
            <?php endif; ?>

            <?php if ($subheading): ?>
                <p class="cta-card-block__subheading"><?php echo esc_html($subheading); ?></p>
            <?php endif; ?>

            <?php if ($cta_link && isset($cta_link['url'], $cta_link['title'])): ?>
                <a
                    href="<?php echo esc_url($cta_link['url']); ?>"
                    class="button button--cta-card"
                    target="<?php echo esc_attr($cta_link['target'] ?? '_self'); ?>"
                >
                    <?php echo esc_html($cta_link['title']); ?> &rarr;
                </a>
            <?php endif; ?>
        </div>
    </div>
</section>
